package com.niit4;

//Simple Program to demonstrate Polymorphism in Java: Example 1.

class Animal {
	public void makeNoise() {
		System.out.println("Some sound");
	}
}

class Dog extends Demo {
	public void makeNoise() {
		System.out.println("Dogs usually Bark!\n");
	}
}

class Cat extends Demo {
	public void makeNoise() {
		System.out.println("Cats usually Meawoo!\n");
	}
}
public class Demo
{
    public static void main(String[] args) {
    	
        Cat a1 = new Cat();
        a1.makeNoise(); //Prints Meowoo
         
        Dog a2 = new Dog();
        a2.makeNoise(); //Prints Bark
    }
}
