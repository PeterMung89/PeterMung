package com.niit1;

import java.util.ArrayList;

//Simple ArrayList Program to print the elements and ArrayList Size.

public class Manager1 {
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(5);
		al.add(12);
		al.add(15);
		al.add(20);
		al.add(7);


		System.out.println("=========================\n");
		System.out.println("The Arraylist elements:\n" + al);
		System.out.println("\n=========================\n");
		System.out.println("Size of the Arraylist:\t" + al.size());
		System.out.println("\n=========================\n");
		

	}

}
