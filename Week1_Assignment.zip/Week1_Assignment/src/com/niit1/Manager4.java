package com.niit1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Manager4 {
	public static void main(String[] args) {

		HashMap<String, ArrayList<String>> map = new HashMap();

		
		ArrayList  al1=new ArrayList();
		ArrayList  al2=new ArrayList();
		
		al1.add("Deependra");
		al2.add("peter");
		
		map.put("key1", al1);
		map.put("key2", al2);

		System.out.println("simplest====");
		System.out.println(map);

		
		System.out.println("\n\n\n\nUsing iterator------");
		Set<String> keys = map.keySet();

		Iterator<String> it = keys.iterator();

		while (it.hasNext()) {

			String key = it.next();

			ArrayList<String> value =(ArrayList<String>) map.get(key);
			
			System.out.println(key +":"+value);
		}



	}
}
