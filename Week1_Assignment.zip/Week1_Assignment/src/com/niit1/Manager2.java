package com.niit1;

import java.util.ArrayList;
import java.util.Collections;

//Simple ArrayList Program sort the elements and swap two elements .

public class Manager2 {

	public static void main(String[] args) {
		int i, sum = 0;
		ArrayList al = new ArrayList();

		al.add(5);
		al.add(200);
		al.add(150);
		al.add(20);
		al.add(7);

		System.out.println("The Unsorted Arraylist elements: " + al);
		System.out.println("\n=========================\n");
		
		//Sorting the ArrayList elements
		Collections.sort(al);
		
		System.out.println("The Sorted Arraylist elements: " + al);
		System.out.println("\n=========================\n");
		
		//Swapping two elements
		Collections.swap(al, 0, 4);
		System.out.println("The Arraylist elements after swapping: " + al);
		System.out.println("\n=========================\n");
	}

}
