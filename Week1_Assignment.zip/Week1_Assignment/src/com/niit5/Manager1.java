package com.niit5;

//Simple Program to demonstrate Type conversion/ type casting in Java: Example 1.

public class Manager1 {
	public static void main(String[] args) {
		//Implicit type casting
		
		int i = 100;
		long l = i; // no explicit type casting required
		float f = l; // no explicit type casting required
		System.out.println("Int value " + i);
		System.out.println("Long value " + l);
		System.out.println("Float value " + f);
	}

}
