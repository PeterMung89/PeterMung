package com.niit5;

//Simple Program to demonstrate Type conversion/ type casting in Java: Example 3.

public class Manager3 {
	// Integer code1

	public static void main(String arg[])
	{
		String s ="27";
		int i=Integer.parseInt(s);
		System.out.println(i);
		Float f=99.7f;
		int j=Integer.parseInt(s);
		System.out.println(f);
	}
}

/*
 * Integer code2 public class CastExample { public static void main(String
 * arg[]) { String s=�27�; int i=(int)s; System.out.println(i); } }
 * 
 * 
 * //Integer to String int a=97; String s=Integer.toString(a);
 * 
 * (or) String s=��+a;
 * 
 * 
 * //Double to String 
 * String s=Double.toString(doublevalue);
 * 
 * //Long to String 
 * String s=Long.toString(longvalue);
 * 
 * //Float to String 
 * String s=Float.toString(floatvalue);
 * 
 * //String to Integer 
 * String s=�7�; int i=Integer.valueOf(s).intValue();
 * 
 * (or) int i = Integer.parseInt(s);
 * 
 * //String to Double 
 * double a=Double.valueOf(s).doubleValue();
 * 
 * //String to Long 
 * long lng=Long.valueOf(s).longValue();
 * 
 * (or) long lng=Long.parseLong(s);
 * 
 * //String to Float 
 * float f=Float.valueOf(s).floatValue();
 * 
 * //Character to Integer 
 * char c=�9�; int i=(char)c;
 * 
 * //String to Character 
 * String s=�welcome�; char c=(char)s;
 */