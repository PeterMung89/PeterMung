package com.niit5;

//Simple Program to demonstrate Type conversion/ type casting in Java: Example 2.

public class Manager2 {
	public static void main(String[] args) {
		// Explicit type casting

		double d = 100.04;
		long l = (long) d; // explicit type casting required
		int i = (int) l; // explicit type casting required

		System.out.println("Double value " + d);
		System.out.println("Long value " + l);
		System.out.println("Int value " + i);

	}

}
