package com.niit2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

//Simple Program to demonstrate Hashmap in Java: Example 2.

public class Manager2 {

	public static void main(String args[]) {

		// Create a hash map
		HashMap hm = new HashMap();
		// Put elements to the map
		hm.put("Bincy", new Double(3434.34));
		hm.put("Harshitha", new Double(123.22));
		hm.put("Mahesh", new Double(1378.00));
		hm.put("Abdur", new Double(99.22));
		hm.put("Manohar", new Double(-19.08));

		// Get a set of the entries
		Set set = hm.entrySet();
		// Get an iterator
		Iterator i = set.iterator();
		// Display elements
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			System.out.print(me.getKey() + ": ");
			System.out.println(me.getValue());
		}
		System.out.println();
		// Deposit 1000 into Zara's account
		double balance = ((Double) hm.get("Bincy")).doubleValue();
		hm.put("Bincy", new Double(balance + 1000));
		System.out.println("Bincy's new balance: " + hm.get("Bincy"));
	}

}
