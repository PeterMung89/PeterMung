package com.niit3;

//Simple Program to demonstrate Interface in Java: Example 1.

interface MyInterface {
	public void method1();

	public void method2();
}

class Manager1 implements MyInterface {
	public void method1() {

		System.out.println("\nThis is implementation of method1");
	}

	public void method2() {
		System.out.println("\nThis is implementation of method2");
	}

	public static void main(String arg[]) {
		MyInterface obj = new Manager1();
		obj.method1();
		obj.method2();
	}
}
