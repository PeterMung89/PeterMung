package com.niit3;

//Simple Program to demonstrate Concrete Class in Java: Example 2.

abstract class A {
	public abstract void methodA();
}

interface B {
	public void printB();
}

public class C extends A implements B {
	public void methodA() {
		System.out.print("I am abstract implementation");
	}

	public void printB() {
		System.out.print("I am interface implementation");
	}
}