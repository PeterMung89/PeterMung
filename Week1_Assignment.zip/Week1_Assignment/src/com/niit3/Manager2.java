package com.niit3;

//Simple Program to demonstrate Abstract Class in Java: Example 1.

abstract class BMW {
	abstract void callme();

	public void bmw() {
		System.out.println("BMW is one of my favourite cars!");

	}
}

abstract class Fer extends BMW {
	abstract void callme();

	public void fer() {
		System.out.println("Ferrari is my second most favourite car!\n");

	}
}

abstract class Lam extends Fer {
	abstract void callme();

	public void lam() {
		System.out.println("Lamborghini is my most favourite car!\n");
	}
}

class Manager2 extends Lam {
	void callme()
	{
		System.out.println("This is a list of my dream cars!\n");
	}

	public static void main(String[] args)
	{
		Manager2 c = new Manager2();
		c.callme();
		c.lam();
		c.fer();
		c.bmw();
	}
}