package com.niit3;

//Simple Program to demonstrate Concrete Class in Java: Example 1.

abstract class Peter{
	public void writeMe() {
		System.out.println("I am done with writing");
	}
}

public class Manager3 extends Peter {
	public void writeMe() {
		System.out.println("I am still writing");
	}

}
