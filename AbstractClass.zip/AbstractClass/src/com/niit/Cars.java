package com.niit;

abstract class BMW {
	abstract void callme();

	public void normal() {
		System.out.println("BMW is one of my favourite cars!");
	}
}

class Cars extends BMW {
	void callme() {
		System.out.println("This is a list of cars!\n");
	}

	public static void main(String[] args) {
		Cars c = new Cars();
		c.callme();
		c.normal();
	}
}