package com.nitt.hostelmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.hostelmanagement.dao.UserDAO;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public Login() {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String Un = (String) request.getParameter("Username");
		String Pw = (String) request.getParameter("Password");

		UserDAO userDAO = new UserDAO();

		if (userDAO.isValidCredentials(Un, Pw) == true) {
			RequestDispatcher rd = request.getRequestDispatcher("Success.html");
			rd.forward(request, response);
		}
		else {
			PrintWriter out = response.getWriter();
			out.print("Invalid Credentials");
			RequestDispatcher rd = request.getRequestDispatcher("Error.html");
			rd.forward(request, response);

		}
	}

}







/*
 * else { PrintWriter out=response.getWriter();
 * 
 * RequestDispatcher rd = request.getRequestDispatcher("Error.html");
 * rd.forward(request, response);
 * 
 * out.print("Invalid Credentials"); rd.include(request,response); } { String un
 * = request.getParameter("Username"); String pw =
 * request.getParameter("Password"); // PrintWriter out=response.getWriter();
 * 
 * if (un.equals(pw)) { // out.println("Correct Credentials");
 * 
 * RequestDispatcher rd = request.getRequestDispatcher("Success.html");
 * rd.forward(request, response);
 * 
 * } else { // out.println("Wrong credentials"); RequestDispatcher rd =
 * request.getRequestDispatcher("Error.html"); rd.forward(request, response);
 * 
 * }
 */
