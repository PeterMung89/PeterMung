package com.niit.hostelmanagement.dao;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/UserDAO")
public class UserDAO extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserDAO() {
		super();

	}

	public boolean isValidCredentials(String Un, String Pw) {
		if (Un.equals("peter") && (Pw.equals("peter"))) {
			return true;
		}
		else {
			return false;

		}

	}

}
