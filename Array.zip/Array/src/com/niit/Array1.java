package com.niit;

import java.util.Arrays;

public class Array1 {
	public static void main(String[] args) {
		int[] myArray = new int[5];
		int i;
		System.out.println("Basic for loop=======");
		for (i = 0; i < myArray.length; i++) {
			myArray[i] = i + 1;
			System.out.println(myArray[i]);
		}
		System.out.println("Enhanced for loop=======");
		{
			for (int element : myArray) {
				System.out.println(element);
			}
		}

		int[] myArray2 = { 12, 25, 6, 7, 10 };
		System.out.println("Sorting the numbers"+(Arrays.toString(myArray2)));
		Arrays.sort(myArray2);
		System.out.println(Arrays.toString(myArray2));
	}
}