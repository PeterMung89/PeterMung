package com.niit;

import java.util.*;

public class ArrayPractice1 {
	public static void main(String args[]) {
		int[] myList = { 3, 6, 1, 19, 5 };
		int i;
		System.out.println("==========================================");
		System.out.println("Printing the array elements in basic loop:");
		System.out.println("==========================================");
		for (i = 0; i < myList.length; i++)
			System.out.println(myList[i]);
		System.out.println("\n\n=============================================");
		System.out.println("Printing the array elements in enhanced loop:");
		System.out.println("=============================================");
		for (int element : myList) {
			System.out.println(element);
		}
		Arrays.sort(myList);
		System.out.println("\n\n===================================");
		System.out.println("Printing the sorted array elements:");
		System.out.println("===================================\n"+(Arrays.toString(myList)));
	}
}
