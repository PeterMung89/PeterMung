package com.niit;

public class Manager2 {

	void test(char a) {

		System.out.println("I m sucessfully being caled by main method");
	}

	public static void main(String[] args) {

		// <<classname>><<refvar_name>>=new <<classname>>();

		// Object creation is done
		Manager2 obj = new Manager2();

		// calling test
		obj.test('a');
	}
}
