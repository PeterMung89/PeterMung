package com.niit;

public class Manager1 {
}
