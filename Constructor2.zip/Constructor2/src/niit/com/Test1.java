package niit.com;

public class Test1 {
	public static void main(String[] args) {

		Product obj1 = new Product();
		obj1.setId(1);
		obj1.setName("Adidas");
		obj1.setPrice(4500d);

		Product obj2 = new Product();
		obj2.setId(2);
		obj2.setName("Puma");
		obj2.setPrice(4000d);

		Product obj3 = new Product();
		obj3.setId(3);
		obj3.setName("Nike");
		obj3.setPrice(3800d);

		Product obj4 = new Product();
		obj4.setId(4);
		obj4.setName("Vans");
		obj4.setPrice(3000d);

		Product obj5 = new Product();
		obj5.setId(5);
		obj5.setName("All Star");
		obj5.setPrice(2800d);

		System.out.println("Item number\t\t" + "Item Name\t\t" + "Price");
		System.out.println("=======================================================");
		System.out.println(obj1.getId() + "\t\t\t" + obj1.getName() + "\t\t\t" + obj1.getPrice());
		System.out.println(obj2.getId() + "\t\t\t" + obj2.getName() + "\t\t\t" + obj2.getPrice());
		System.out.println(obj3.getId() + "\t\t\t" + obj3.getName() + "\t\t\t" + obj3.getPrice());
		System.out.println(obj4.getId() + "\t\t\t" + obj4.getName() + "\t\t\t" + obj4.getPrice());
		System.out.println(obj5.getId() + "\t\t\t" + obj5.getName() + "\t\t" + obj5.getPrice());
		System.out.println("==============Without using Constructor================");
		System.out.println("=======================================================");

		System.out.println("\n\n==================By using Constructor=================");
		System.out.println("=======================================================");
		System.out.println("Item number\t\t" + "Item Name\t\t" + "Price");
		System.out.println("=======================================================");

		int id = obj1.getId();
		String name = obj1.getName();
		double price = obj1.getPrice();
		System.out.println(id + "\t\t\t" + name + "\t\t\t" + price);

		id = obj2.getId();
		name = obj2.getName();
		price = obj2.getPrice();
		System.out.println(id + "\t\t\t" + name + "\t\t\t" + price);

		id = obj3.getId();
		name = obj3.getName();
		price = obj3.getPrice();
		System.out.println(id + "\t\t\t" + name + "\t\t\t" + price);

		id = obj4.getId();
		name = obj4.getName();
		price = obj4.getPrice();
		System.out.println(id + "\t\t\t" + name + "\t\t\t" + price);

		id = obj5.getId();
		name = obj5.getName();
		price = obj5.getPrice();
		System.out.println(id + "\t\t\t" + name + "\t\t" + price);
	}

}
