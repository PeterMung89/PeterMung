package niit.com;

public class Product {

	private int id;
	private String name;
	private double price;
	
	//getter and setter for "id"
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	//getter and setter for "name"
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//getter and setter for "price"
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
