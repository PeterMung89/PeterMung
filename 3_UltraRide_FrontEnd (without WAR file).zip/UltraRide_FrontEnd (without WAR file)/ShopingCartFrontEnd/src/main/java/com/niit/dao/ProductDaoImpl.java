package com.niit.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.model.Product;

//DAO   Implementation class

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public ProductDaoImpl() {
		// System.out.println("ProductDaoImpl constructor invoked---");
	}

	List<Product> products = null;

	// For One product
	public List<Product> getProduct(String name) {
		System.out.println("ProductDao  getProduct  invoked*********");
		products = new ArrayList<Product>();

		Product pm1 = null;

		if ("Bike1".equals(name))
			pm1 = new Product(1, "Yamaha1", "Two Wheeler", 56000);
		if ("Bike2".equals(name))
			pm1 = new Product(2, "Yamaha2", "Two Wheeler", 40000);
		if ("Bike3".equals(name))
			pm1 = new Product(3, "Yamaha3", "Two Wheeler", 65000);
		if ("Bike4".equals(name))
			pm1 = new Product(4, "Yamaha4", "Two Wheeler", 75000);
		if ("Bike5".equals(name))
			pm1 = new Product(5, "Yamaha5", "Two Wheeler", 68000);
		if ("Bike6".equals(name))
			pm1 = new Product(6, "Yamaha6", "Two Wheeler", 55000);
		
		if ("Bike7".equals(name))
			pm1 = new Product(7, "Yamaha7", "Two Wheeler", 73000);
		if ("Bike8".equals(name))
			pm1 = new Product(8, "Yamaha8", "Two Wheeler", 89500);

		products.add(pm1);

		return products;
	}

	// For all products
	public List<Product> getAllProducts() {
		System.out.println("ProductDao  getAllProducts  invoked*********");

		products = new ArrayList<Product>();
		Product p1 = new Product(1, "Yamaha1", "Two Wheeler", 56000);
		Product p2 = new Product(2, "Yamaha2", "Two Wheeler", 40000);
		Product p3 = new Product(3, "Yamaha3", "Two Wheeler", 65000);
		Product p4 = new Product(4, "Yamaha4", "Two Wheeler", 75000);
		Product p5 = new Product(5, "Yamaha5", "Two Wheeler", 68000);
		Product p6 = new Product(6, "Yamaha6", "Two Wheeler", 55000);
		Product p7 = new Product(7, "Yamaha7", "Two Wheeler", 73000);
		Product p8 = new Product(8, "Yamaha8", "Two Wheeler", 89500);
		products.add(p1);
		System.out.println("First record added--");
		products.add(p2);
		System.out.println("Second record added--");
		products.add(p3);
		System.out.println("Third record added--");
		products.add(p4);
		products.add(p5);
		products.add(p6);
		products.add(p7);
		products.add(p8);
		return products;
	}

	// All products
	/*
	 * public List<Product> getProducts() {
	 * 
	 * List<Product> productlist = null;
	 * 
	 * try { Session session = sessionFactory.openSession();
	 * 
	 * System.out.println("Session:" + session.isOpen());
	 * 
	 * // 1.Read Product System.out.println(
	 * "***********************Read AllProducts***************"); Criteria ctr =
	 * session.createCriteria(Product.class); productlist = ctr.list(); for
	 * (Product p : productlist) { System.out.println(p.getpId() + "\t" +
	 * p.getpName() + "\t" + p.getPrice() + "\t" + p.getpDescription()); }
	 * 
	 * System.out.println(
	 * "\n***********************Read Product By ProductId***************"); //
	 * 2.Get ProductBy Id
	 * 
	 * Product prod = (Product) session.load(Product.class, 1);
	 * 
	 * System.out.println( prod.getpId() + "\t" + prod.getpName() + "\t" +
	 * prod.getPrice() + "\t" + prod.getpDescription());
	 * 
	 * // 3. Update product SQLQuery sqlquery = session.createSQLQuery(
	 * "select * from  ALLPRODUCT where pId=1");
	 * sqlquery.addEntity(com.niit.model.Product.class); List<Product> list =
	 * sqlquery.list(); for (Product per : list)
	 * 
	 * {
	 * 
	 * per.setpId(5); per.setpName("Some new "); per.setPrice(6588.09);
	 * per.setpDescription("some new Description");
	 * 
	 * session.update(per); }
	 * 
	 * // 4.Delete Product Product prod2 = (Product) session.load(Product.class,
	 * 1); session.delete(prod2);
	 * 
	 * }
	 * 
	 * catch (Exception ex) {
	 * 
	 * System.out.println("Exception occures.."); ex.printStackTrace();
	 * 
	 * }
	 * 
	 * return productlist;
	 * 
	 * }
	 * 
	 */

}
