package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.dao.ProductDaoImpl;
import com.niit.model.Product;
import com.niit.service.ProductService;

@Controller
public class MyController {

	String setName = "";

	public MyController() {

	}

	@RequestMapping("/login")
	public String login() {

		return "login";
	}

	@RequestMapping("/registration")
	public String registration() {

		return "reg";
	}

	@RequestMapping("/prod")
	public ModelAndView getproduct(@RequestParam(value = "name", required = false, defaultValue = "img") String name) {
		System.out.println("My controller getproduct invoked*****************");
		ModelAndView allprod = new ModelAndView("allproducts");
		setName = name;
		return allprod;
	}

	List<Product> products;

	@RequestMapping("/GsonConvert")
	public @ResponseBody String getValues() {

		System.out.println("My controller GsonConvert invoked********************** ");
		ProductDaoImpl dao = new ProductDaoImpl();
		if (setName.equals("Bike1") || setName.equals("Bike2") || setName.equals("Bike3") || setName.equals("Bike4")
				|| setName.equals("Bike5") || setName.equals("Bike6") || setName.equals("Bike7")
				|| setName.equals("Bike8")) {
			products = dao.getProduct(setName);

		} else if (setName.equals("Allpro")) {
			products = dao.getAllProducts();
		}

		Gson gson = new Gson();
		String result = gson.toJson(products);
		return result;
	}

}
