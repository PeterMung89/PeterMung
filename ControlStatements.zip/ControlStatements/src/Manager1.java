import java.util.Scanner;

public class Manager1 {
	public static void main(String args[]) {
		int a, b;
		System.out.println("Enter first number");
		Scanner s1 = new Scanner(System.in);
		a = s1.nextInt();
		System.out.println("Enter second number");
		Scanner s2 = new Scanner(System.in);
		b = s2.nextInt();
		if (a > b)
			System.out.println(a +" is greater than " + b);
		else
			System.out.println(b +" is greater than " + a);

	}
}
