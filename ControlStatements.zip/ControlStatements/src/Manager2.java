import java.util.Scanner;

public class Manager2 {
	public static void main(String args[]) {
		int a;
		System.out.println("Enter any value from 0-6:");
		Scanner s1=new Scanner(System.in);
		a=s1.nextInt();
		switch(a)
		{
		default:
			System.out.println("Invalid input! Check the number again!!!");
			break;
		case 0:
			System.out.println("Monday");
			break;
		case 1:
			System.out.println("Tuesday");
			break;
		case 2:
			System.out.println("Wednesday");
			break;
		case 3:
			System.out.println("Thursday");
			break;
		case 4:
			System.out.println("Friday");
			break;
		case 5:
			System.out.println("Saturday");
			break;
		case 6:
			System.out.println("Sunday");
			break;
		
		}
	}

}
