package com.niit;

public class Manager1 {
	private int id;
	private String name;
	private double price;
	public int getID()
	{
		return id;
	}
	public void setID(int id)
	{
		this.id=id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

}
