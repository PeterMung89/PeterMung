package com.niit;

public class Test {
	public static void main(String[] args) {
		Manager1 manager=new Manager1();
		
		manager.setID(101);
		manager.setName("Mobile");
		manager.setPrice(10000d);
		
		System.out.println("id:"+manager.getID());
		System.out.println("name:"+manager.getName());
		System.out.println("price:"+manager.getPrice());
	}

}
