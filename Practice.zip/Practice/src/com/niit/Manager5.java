package com.niit;

//Use of semicolon after "for" in a "simple for loop"

public class Manager5 {
	public static void main(String[] args) {
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("Without the semicolon!"+i);
		}
		for(i=1;i<=10;i++);
		{
			System.out.println("\n\nAfter putting semicolon!\n\n"+i);
		}
	}
}
