package com.niit;

//Use of semicolon after "else" in a "if-else condition"

public class Manager2 {

	public static void main(String[] args) {
		int a = 50;
		int b = 20;
		if (a > b) {
			System.out.println("A is greatest");
		} else
			;
		// use of semicolon (";") will execute the statement without checking
		// the condition!!!
		{
			System.out.println("B is greatest");
		}
	}

}
