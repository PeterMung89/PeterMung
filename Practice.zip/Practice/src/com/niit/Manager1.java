package com.niit;

//Use of semicolon after "if" in a "simple if condition"

public class Manager1 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		if (a > b);
		{
			System.out.println("A is greatest");
		}
		if (b > a) {
			System.out.println("B is greatest");
		}
	}

}
