package com.niit;

//Use of semicolon after "else" or "if" in a "nested-if-else condition"

public class Manager3 {

	public static void main(String[] args) {
		int a = 30;
		int b = 190;
		int c = 100;
		if (a > b) {
			if (a > c)
				System.out.println("A is greatest");
		} else if (b > a) {
			if (b > c)
				System.out.println("B is greatest");
		} else {
			System.out.println("C is greatest");
		}

	}

}
