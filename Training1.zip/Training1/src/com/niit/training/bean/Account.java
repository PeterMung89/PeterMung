package com.niit.training.bean;

public class Account {

	// Properties
	private int accid;
	private String accname;

	// Getters and setters
	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	public String getAccname() {
		return accname;
	}

	public void setAccname(String accname) {
		this.accname = accname;
	}

	@Override
	public String toString() {
		return "Account [accid=" + accid + ", accname=" + accname + "]";
	}

}
