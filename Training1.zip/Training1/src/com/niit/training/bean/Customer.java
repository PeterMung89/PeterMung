package com.niit.training.bean;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {

	// Customer Properties
	private String shippingAddress;
	private String permanentAddress;
	private List myAccounts = new ArrayList();

	// Getters and setters

	public String getShippingAddress() {
		return shippingAddress;
	}

	public List getMyAccounts() {
		return myAccounts;
	}

	public void setMyAccounts(List myAccounts) {
		this.myAccounts = myAccounts;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	@Override
	public String toString() {
		return "Customer [shippingAddress=" + shippingAddress + ", permanentAddress=" + permanentAddress
				+ ", myAccounts=" + myAccounts +"]" +super.toString();
	}

}