package com.niit.training;

import java.util.ArrayList;
import java.util.List;

import com.niit.training.bean.Account;
import com.niit.training.bean.Customer;

public class Test {

	public static void main(String[] args) {

		// Customer created
		Customer cust = new Customer();
		cust.setId("101");
		cust.setName("Cust1");
		cust.setPassword("NIIT");
		cust.setShippingAddress("Peter shipping address");
		cust.setPermanentAddress("peter permanent  address");

		// Create account
		// First account
		Account ac = new Account();
		ac.setAccid(30431);
		ac.setAccname("peter1");

		// Create accounts List
		List accounts = new ArrayList();
		// add first account
		accounts.add(ac);

		// create sec account
		ac = new Account();
		ac.setAccid(30432);
		ac.setAccname("peter2");

		// add second account
		accounts.add(ac);

		cust.setMyAccounts(accounts);
		
		System.out.println(cust);

	}

}
