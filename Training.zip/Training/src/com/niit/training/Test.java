package com.niit.training;

import com.niit.training.bean.Account;
import com.niit.training.bean.Customer;

public class Test {

	public static void main(String[] args) {

		// Customer created
		Customer cust = new Customer();
		cust.setId("101");
		cust.setName("Cust1");
		cust.setPassword("NIIT");
		cust.setShippingAddress("Peter shipping address");
		cust.setPermanentAddress("peter permanent  address");

		// Create account
		Account ac = new Account();
		ac.setId(10001);
		ac.setName("SB");

		/// Adding account to the customer
		cust.setMyAccount(ac);

		System.out.println(cust);
	}

}
