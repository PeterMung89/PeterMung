package com.niit.training.bean;

public class Customer extends User {

	private String shippingAddress;
	public String permanentAddress;
	public Account myAccount;

	public Account getMyAccount() {
		return myAccount;
	}

	public void setMyAccount(Account myAccount) {
		this.myAccount = myAccount;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	@Override
	public String toString() {
		return "Customer [shippingAddress=" + shippingAddress + ", permanentAddress=" + permanentAddress
				+ ", myAccount=" + myAccount + "]";
	}

}