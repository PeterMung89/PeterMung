package com.niit;
class C{
	int c=300;
}
class B extends C {

	int b = 200+c-c;

}

class A extends B {

	int a = 100;

	 void add() {
		int sum = a + b+c;
		System.out.println(sum);

	}
}

public class Manager extends A {

	public static void main(String[] args) {

		Manager obj = new Manager();
		System.out.println("First number : "+obj.c);
		System.out.println("Second number : "+obj.b);
		System.out.println("Third number : "+obj.a);
		System.out.println("Sum : ");
		// System.out.println(obj.b);
		A obj1 = new A();
		obj1.add();
		//A.add(); if I use static....

	}

}
