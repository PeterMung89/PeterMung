package com.niit1;
class England{
	void dispEng(){
		System.out.println("England is one of the strongest countries in Football World!");
	}
}
class EPL extends England{
	void dispEPL(){
		System.out.println("EPL is one of the best football leagues in the world");
	}
}
public class Arsenal extends EPL {
	public static void main(String args[]){
		System.out.println("Arsenal is one of the best football clubs in Premiere League");
		EPL obj1=new EPL();
		obj1.dispEPL();
		England obj2=new England();
		obj2.dispEng();	
	}

}
