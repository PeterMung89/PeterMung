package com.niit;

public class CustomMethod {

	static void test() {

		System.out.println("I' m inside test");

	}

	public static void main(String args[]) {

		test();
	}

}