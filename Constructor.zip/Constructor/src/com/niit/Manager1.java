package com.niit;

public class Manager1 {

	private int id;
	private String name;
	private double price;

	// Argument const
	public Manager1(int id, String name, double price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public Manager1(String name) {

		this.name = name;
	}

	// Default const

	public Manager1() {

	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

}
