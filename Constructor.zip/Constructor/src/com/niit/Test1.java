package com.niit;

public class Test1 {

	public static void main(String[] args) {

		// Object creation + property init is also done
		Manager1 obj = new Manager1(1, "New Peter", 66);

		System.out.println(obj.getId() + "\t" + obj.getName() + "\t" + obj.getPrice());

		// Third const

		System.out.println("===================");
		System.out.println("Only the name is set!!!");
		System.out.println("===================");
		Manager1 obj3 = new Manager1("Third Peter");

		System.out.println(obj3.getId() + "\t" + obj3.getName() + "\t" + obj3.getPrice());
	}
}
