package com.niit;

public class Test {

	public static void main(String[] args) {

		// Object creation
		Manager1 obj = new Manager1();

		// Calling setters
		obj.setId(0);
		obj.setName("peter");
		obj.setPrice(1647.77);

		// Calling getters
		int id = obj.getId();
		String name = obj.getName();
		double price = obj.getPrice();

		System.out.println(id + "\t" + name + "\t" + price);

	}

}
