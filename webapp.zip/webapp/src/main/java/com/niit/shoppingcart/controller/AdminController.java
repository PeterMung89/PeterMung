package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.AdminDao;

@Controller
public class AdminController {

	@Autowired
	AdminDao adminDao;

	@RequestMapping("/isValidateAdmin")
	public ModelAndView validate(@RequestParam(value = "name") String username,
			@RequestParam(value = "password") String password) {

		ModelAndView mv = null;
		String message = null;
		if (adminDao.isValidUser(username, password)) {

			message = "Valid Credentials..!!";

			mv = new ModelAndView("adminHome");
			mv.addObject("message", message);
			mv.addObject("name", username);

		}

		else {

			message = "InValid Credentials..!!";

			mv = new ModelAndView("Login");
			mv.addObject("message", message);
			mv.addObject("name", username);

		}
		return null;

	}
}
