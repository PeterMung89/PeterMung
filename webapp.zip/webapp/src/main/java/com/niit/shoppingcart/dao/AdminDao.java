package com.niit.shoppingcart.dao;

import org.springframework.stereotype.Repository;

@Repository
public class AdminDao {

	public boolean isValidUser(String username, String password) {

		boolean flag = false;
		if (username.equals("peter") && password.equals("pass")) {

			flag = true;
		}

		else {

			flag = false;
		}

		return flag;
	}

}
